<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'cfiot_team2' );

/** Database username */
define( 'DB_USER', 'admin' );

/** Database password */
define( 'DB_PASSWORD', 'cfiot2J@y@' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '.Av`!g4k/~H `Yg2%LuV^EA}{:$FI9UIRd.qZ[Z^p <@r5g=VJu0A}FD!y3%~ctn' );
define( 'SECURE_AUTH_KEY',  '?%_SuyC $#k)sU%ri Sl[%;IAql]MJ1S8kcv7n7 &cCG_>P,_5&A,}sTq|n.1YdT' );
define( 'LOGGED_IN_KEY',    '[0{IbGNwCOz!zS$qTH@Or#iawU]evT!K|k)xUb^qA`{_kR^]ZdPi6d?Dq3gYeWzn' );
define( 'NONCE_KEY',        '<U}QU8~[tTTu(o|pYn2[B?8mP$ABSuK|3|wgGc6QS)hHJ{wj(XB%I?/)uxGbK{4`' );
define( 'AUTH_SALT',        'hpiI$Nq!*S6P8duV@2$rdKDyHK$Rwy vrWK!DW 4BZ23Wy?V4qAA[h]N#m#3XeUf' );
define( 'SECURE_AUTH_SALT', 'D _{=fed~|+Xj,7RUXius]6A`TUVL1*F^Mr5FCx5;2]$gEGhM*)vI wjol*SFB%S' );
define( 'LOGGED_IN_SALT',   'bmlmByFxnkX0UltaoGaOQd:Db-bFSRZqm5{6@t`H@rAwZAz~_7_y#&]?<$pD=9V<' );
define( 'NONCE_SALT',       'h(s^<:JDzPp0(8&ZilnT_^[!+D!<&<%Z95b YJJn-Q9ZOcsUf#17JLvHfCQ eE.n' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
